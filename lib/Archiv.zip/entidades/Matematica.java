package entidades;

public interface Matematica {

    
    static float pi = 3.14f;
    
    public int soma(int a, int b);

}
