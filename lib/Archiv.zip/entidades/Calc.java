package entidades;

public class Calc implements Matematica {

    
    public Calc(){}
    
    public int soma(int a, int b){
        return a+b;
    }

}
